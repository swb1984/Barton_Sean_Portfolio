﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barton_Sean_Class_Object_Assignment
{
    /*
     *Sean Barton
     * April 16, 2016
     * Class Object Assignment
      */
    class Program
    {
        static void Main(string[] args)
        {
            //User input variables
            string job;
            string degree;
            string name;
            //Ask for user input
            Console.Write("What's your name?");
            name = Console.ReadLine();
            Console.Write("What's your degree in?");
            degree = Console.ReadLine();
            Console.Write("What's your job title?");
            job = Console.ReadLine();
            //Instantiation
            Job jobOne = new Job(name, degree, job);
            Console.WriteLine("Hello, " + jobOne.getName() + "!");
            Console.WriteLine("You have a degree in " + jobOne.getDegree() + " and work as a " + jobOne.getJob() + ".");
            /*
             *I tested using the letter S for name, MDV for degree and FSE for job
             * I tested using Sean for name, Mobile Dev for degree and Field Service for job
             * I tested using SWB for name, Mobile Development for degree and Field Service Engineer for job
             */

        }

    }
}

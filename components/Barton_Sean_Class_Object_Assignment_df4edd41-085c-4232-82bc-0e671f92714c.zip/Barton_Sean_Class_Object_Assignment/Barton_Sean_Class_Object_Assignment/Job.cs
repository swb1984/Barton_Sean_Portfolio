﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barton_Sean_Class_Object_Assignment
{
    class Job
    {
        //Variables
        string mJob;
        string mDegree;
        string mName;
        //Constructor
        public Job (string _name, string _degree, string _job)
        {
            mJob = _job;
            mDegree = _degree;
            mName = _name;
        }
        //Getters
        public string getJob()
        {
            return mJob;
        }
        public string getDegree()
        {
            return mDegree;
        }
        public string getName()
        {
            return mName;
        }
        //Setters
        public void setJob(string _job)
        {
            mJob = _job;
        }
        public void setDegree(string _degree)
        {
            mDegree = _degree;
        }
        public void setName(string _name)
        {
            mName = _name;
        }
    }
}
